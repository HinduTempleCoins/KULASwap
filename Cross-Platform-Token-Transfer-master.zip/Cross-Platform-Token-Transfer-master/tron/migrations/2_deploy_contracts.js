var Bridge = artifacts.require("./Bridge.sol");

module.exports = function(deployer) {
  deployer.deploy(Bridge);
};
