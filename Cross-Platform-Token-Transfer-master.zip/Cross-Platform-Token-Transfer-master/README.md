# Cross-Platform-Token-Transfer
This repo aims to fill the gap between TRON network and Binance Smart Chain and make a Bridge between them.
